
import json

def lambda_handler(event, context):
    food_and_drinks = {
        "food": [
            {"name": "Pizza", "price": "$10"},
            {"name": "Burger", "price": "$5"},
            {"name": "Doner Kebab", "price": "$8"},
            {"name": "Popcorn", "price": "$3"},
            {"name": "Cake", "price": "$12"}
        ],
        "drinks": [
            {"name": "Coca Cola", "price": "$2"},
            {"name": "Pepsi", "price": "$2"},
            {"name": "Mirinda", "price": "$2"},
            {"name": "Fanta", "price": "$2"},
            {"name": "Orange Juice", "price": "$4"}
        ]
    }
    return {
        'statusCode': 200,
        'headers': {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"},
        'body': json.dumps(food_and_drinks)
    }
